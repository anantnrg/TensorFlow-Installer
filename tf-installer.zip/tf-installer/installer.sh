sudo bash src/splash.sh
