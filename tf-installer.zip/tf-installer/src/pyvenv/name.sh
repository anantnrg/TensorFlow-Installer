name=$(zenity --entry --title="Python VirtualEnv Name" --text="Enter a name for the VirtualEnv:")
python3 -m venv ~/$name
