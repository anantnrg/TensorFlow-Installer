
(
# =================================================================
echo "# Loading Installer Files" ; sleep 2


# =================================================================
echo "25"
echo "# Checking Environments" ; sleep 2


# =================================================================
echo "50"
echo "# Configuring Installer For Environments" ; sleep 2


# =================================================================
echo "65"
echo "# Loading Python VirtualEnv" ; sleep 2



# =================================================================
echo "75"
echo "# Loading Ananconda If Exists" ; sleep 2

# =================================================================
echo "# Please Wait...." ; sleep 2
echo "82"

echo "100"
echo "# Please Click OK to continue" ; sleep 0


) |
zenity --progress \
  --title="TensorFlow Installer" \
  --text="Tensorflow Installer by Anant Narayan" \
  --percentage=0

if [ "$?" = -1 ] ; then
        zenity --error \
          --text="You Cancelled The Installer!"
fi
sudo bash ~/tf-installer/src/env.sh
