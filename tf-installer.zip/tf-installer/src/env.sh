#!/bin/bash
ans=$(zenity  --list  --text "Choose an Environment" --radiolist  --column "Pick" --column "Environment" TRUE "VirtualEnv" FALSE "Ananconda3");
echo $ans
if [ $ans == "VirtualEnv" ]; then
   sudo bash ~/tf-installer/src/pyvenv/name.sh &
elif [ $ans == "Ananconda3" ]; then
   sudo bash ~/tf-installer/src/ananconda/name.sh &
else
   zenity --error --text "Unknown Environment "
fi
